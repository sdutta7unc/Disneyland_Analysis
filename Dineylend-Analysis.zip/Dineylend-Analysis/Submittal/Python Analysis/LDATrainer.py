from gensim import corpora, models
import pyLDAvis
import pyLDAvis.gensim_models

class LDATrainer():
    def __init__(self, tokens, unigrams=False):
        joined_ngrams = None
        if unigrams:
            joined_ngrams = [[''.join(gram) for gram in doc] for doc in tokens]
        else:
            joined_ngrams = [[' '.join(gram) for gram in doc] for doc in tokens]

        self.dictionary = corpora.Dictionary(joined_ngrams)
        self.corpus = [self.dictionary.doc2bow(text) for text in joined_ngrams]
        self.lda_model = None

    def train(self, n_topics):
        self.lda_model = models.LdaModel(corpus=self.corpus, 
                                        num_topics=n_topics,
                                        id2word=self.dictionary, 
                                        passes=15,
                                        alpha='auto',
                                        per_word_topics=True)

    def list_topics(self):
        for idx, topic in self.lda_model.print_topics(-1):
            print(f"Topic {idx}: {topic}")

    def save_to_file(self, file_name):
        vis = pyLDAvis.gensim_models.prepare(self.lda_model, self.corpus, self.dictionary)
        pyLDAvis.save_html(vis, f'{file_name}.html')
        return vis

    def get_topics(self):
        def get_topic(text):
            bow = self.dictionary.doc2bow(text)
            topic_scores = self.lda_model.get_document_topics(bow)
            return sorted(topic_scores, key=lambda x: x[1], reverse=True)[0][0]
    
        return self.tokens.apply(get_topic)