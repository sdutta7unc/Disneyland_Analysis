1. Make sure Python (Python3) is installed. Any version should work, e.g., 3.8 or 3.11.
2. Open up your terminal and change directory to the folder with the scripts. (For windows: cd C:\Users\alic\Projects\TextMiningScript)
3. Run "pip install -r requirements.txt" without quotes. (may need to change pip to pip3)
4. Run "python analyze.py" (may need to change python to python3)
5. Optionally, add command line arguments, e.g., "python analyze.py --topics=2 --minfreq=10".

Command line arguments:
1. --topics refers to the # of topics used in the LDA modeling. Default is 2. Example: --topics=2
2. --minfreq refers to the minimum frequency of terms in the unigram, bigram, and trigram tokens. Default is 0. Example: --minfreq=10
3. --skiplda refers to skipping the LDA analysis as this can be time consuming. Default is False. Example: --skiplda=True

Custom Stopwords text file: 
* You can add additional words to ignore in the analysis. For example, "park" or "ride" may not be very important in our analysis.
* Each word is on a new line. 