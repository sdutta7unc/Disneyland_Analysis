from collections import Counter
import string
import os
import pandas as pd
import nltk
import argparse
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.util import ngrams
from wordcloud import WordCloud
from textblob import TextBlob
from datetime import datetime

from LDATrainer import LDATrainer

def create_directory_if_not_exists(dir):
    if not os.path.exists(dir):
        os.makedirs(dir)

now = datetime.now()
current_time = now.strftime("%H%M%S")

output_dir = f'output-{current_time}'

create_directory_if_not_exists(f'{output_dir}/topics')
create_directory_if_not_exists(f'{output_dir}/wordclouds')
create_directory_if_not_exists(f'{output_dir}/frequencies')

parser = argparse.ArgumentParser(description='Process some integers.')

parser.add_argument('--topics', type=int, default=2, help='Number of topics')
parser.add_argument('--minfreq', type=int, default=0, help='Minimum frequency')
parser.add_argument('--skiplda', type=bool, default=False, help='Skip LDA Analysis')

# Parse the arguments
args = parser.parse_args()

nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

def print_info(text):
    print(f'[Info] {text}')

print_info('Loading file...')

df = pd.read_csv('Original.csv', encoding='latin1', na_values=['missing'])

df.drop(columns=['Review_ID'], inplace=True)
df['Year_Month'] = pd.to_datetime(df['Year_Month'], format='%Y-%m')
df = df.loc[df['Branch'] == 'Disneyland_California']

print_info('Calculating sentiment...')

df['Sentiment'] = df['Review_Text'].apply(lambda text : TextBlob(text).sentiment.polarity)

print_info('Loading stopwords...')

stop_words = stopwords.words('english')
punctuation = set(string.punctuation)

if os.path.isfile("custom_stopwords.txt"):
    with open('custom_stopwords.txt', 'r') as f:
        custom_stop_words = [word.strip() for word in f.read().split()]

stop_words.extend(custom_stop_words)

lemmatizer = WordNetLemmatizer()

stop_words = set(stop_words)
punctuation = set(punctuation)

def get_tokens(text):
    tokens = word_tokenize(text.lower())
    lemmatized_tokens = [lemmatizer.lemmatize(token) for token in tokens if token.isalpha()]
    filtered_tokens = [token for token in lemmatized_tokens if token not in stop_words and token not in punctuation]
    return filtered_tokens

print_info('Lemmatizing and tokenizing...')

df['Tokens'] = df['Review_Text'].apply(get_tokens)

token_counts = Counter([token for tokens_list in df['Tokens'] for token in tokens_list])
bigram_counts = Counter([bigram for tokens_list in df['Tokens'] for bigram in ngrams(tokens_list, 2)])
trigram_counts = Counter([trigram for tokens_list in df['Tokens'] for trigram in ngrams(tokens_list, 3)])

# Filter based on minimum frequency
df['Tokens'] = df['Tokens'].apply(lambda tokens: [token for token in tokens if token_counts[token] >= args.minfreq])
df['Bigrams'] = df['Tokens'].apply(lambda tokens: [bigram for bigram in ngrams(tokens, 2) if bigram_counts[bigram] >= args.minfreq])
df['Trigrams'] = df['Tokens'].apply(lambda tokens: [trigram for trigram in ngrams(tokens, 3) if trigram_counts[trigram] >= args.minfreq])

positive = df[df['Rating'] >= 4]

negative = df[df['Rating'] < 4]

def generate_wordcloud(tokens, file_name):
    tokens = [' '.join(token) for token in tokens]
    text = ' '.join(tokens)
    wordcloud = WordCloud(width=800, height=400).generate(text)
    wordcloud.to_file(f'{output_dir}/wordclouds/' + file_name)

# Print some sample tokens
print_info('Sample tokens for positive reviews:')
print(positive['Tokens'].values[:5])

print_info('Sample tokens for negative reviews:')
print(negative['Tokens'].values[:5])


print_info('Generating wordclouds...')

generate_wordcloud(positive['Tokens'], 'positive.png')
generate_wordcloud(negative['Tokens'], 'negative.png')

def train_lda(tokens, file_name, n_topics=2):
    lda = LDATrainer(tokens)
    lda.train(n_topics=n_topics)
    lda.save_to_file(file_name=f'{output_dir}/topics/' + file_name)

if not args.skiplda:
    print_info('Training positive unigrams LDA...')
    train_lda(positive['Tokens'], 'positive-unigrams-lda', n_topics=args.topics)

    print_info('Training positive bigrams LDA...')
    train_lda(positive['Bigrams'], 'positive-bigrams-lda', n_topics=args.topics)

    print_info('Training positive trigrams LDA...')
    train_lda(positive['Trigrams'], 'positive-trigrams-lda', n_topics=args.topics)

    print_info('Training negative unigrams LDA...')
    train_lda(negative['Tokens'], 'negative-unigrams-lda', n_topics=args.topics)

    print_info('Training negative bigrams LDA...')
    train_lda(negative['Bigrams'], 'negative-bigrams-lda', n_topics=args.topics)

    print_info('Training negative trigrams LDA...')
    train_lda(negative['Trigrams'], 'negative-trigrams-lda', n_topics=args.topics)

print_info('Saving processed CSV file...')

df.to_csv(f'{output_dir}/Processed.csv', mode='w')


def get_rating_filtered_df(rating):
    return df[df['Rating'] == rating]


def get_unigrams_counter(rating):
    filtered_df = get_rating_filtered_df(rating)
    return Counter([token for tokens_list in filtered_df['Tokens'] for token in tokens_list])


def get_bigrams_counter(rating):
    filtered_df = get_rating_filtered_df(rating)
    return Counter([bigram for tokens_list in filtered_df['Tokens'] for bigram in ngrams(tokens_list, 2)])


def get_trigrams_counter(rating):
    filtered_df = get_rating_filtered_df(rating)
    return Counter([trigram for tokens_list in filtered_df['Tokens'] for trigram in ngrams(tokens_list, 3)])


def write_counter_file(counter, file_name):
    with open(f'{output_dir}/frequencies/' + file_name + '.csv', 'w') as f:
        f.write('word,frequency\n')
        for k,v in  counter.most_common():
            word = str(k).translate(str.maketrans({'(': '', ')': '', '\'': '', ',': ''}))
            frequency = str(v).translate(str.maketrans({'(': '', ')': '', '\'': '', ',': ''}))
            f.write("{},{}\n".format(word, frequency))


for rating in range(1, 6):
    print_info(f'Saving frequency distributions for {rating} rating unigrams...')
    write_counter_file(get_unigrams_counter(rating=rating), f'{rating}-rating-unigrams')
    
    print_info(f'Saving frequency distributions for {rating} rating bigrams...')
    write_counter_file(get_bigrams_counter(rating=rating), f'{rating}-rating-bigrams')

    print_info(f'Saving frequency distributions for {rating} rating trigrams...')
    write_counter_file(get_trigrams_counter(rating=rating), f'{rating}-rating-trigrams')


print_info('Done!')